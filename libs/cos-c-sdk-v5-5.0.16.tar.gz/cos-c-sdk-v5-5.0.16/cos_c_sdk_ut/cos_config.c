#include "cos_config.h"

char* TEST_COS_ENDPOINT = NULL;
char* TEST_ACCESS_KEY_ID = NULL;
char* TEST_ACCESS_KEY_SECRET = NULL;
char* TEST_BUCKET_NAME = NULL;
char* TEST_APPID = NULL;

